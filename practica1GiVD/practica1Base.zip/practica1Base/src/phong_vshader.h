#ifndef PHONG_VSHADER_H
#define PHONG_VSHADER_H


class phong_vshader
{
public:
    phong_vshader();
};

#endif // PHONG_VSHADER_H