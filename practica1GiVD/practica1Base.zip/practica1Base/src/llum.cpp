#include "llum.h"

Llum::Llum(Lights t){

    switch(t) {
        case Puntual:
            name = "puntual";
            id = 0;
            type = t;
            position = vec4(2.0,2.0,2.0,0);
            direction = vec4(2.0,2.0,2.0,0);
            diffuse = vec3(0.8,0.8,0.8);
            ambient = vec3(0.2, 0.2, 0.2);
            specular = vec3(1.0,1.0,1.0);
            a = 0.0f;
            b = 0.0f;
            c = 1.0f;
        break;

        case Direccional:
            name = "direccional";
            id = 1;
            type = t;
            direction = vec4(2.0,2.0,2.0,0);
            diffuse = vec3(0.8,0.8,0.8);
            ambient = vec3(0.2, 0.2, 0.2);
            specular = vec3(1.0,1.0,1.0);
            a = 0.0f;
            b = 0.0f;
            c = 1.0f;
        break;

        case SpotLight:
            name = "spotlight";
            id = 2;
            type = t;
            position = vec4(2.0,2.0,2.0,0);
            angle = 0.5f;
            direction = vec4(2.0,2.0,2.0,0);
            diffuse = vec3(0.8,0.8,0.8);
            ambient = vec3(0.2, 0.2, 0.2);
            specular = vec3(1.0,1.0,1.0);
            a = 0.0f;
            b = 0.0f;
            c = 1.0f;
        break;
      }

}

Llum::Llum(QString name, point4 position, point4 direction, GLfloat angle, GLfloat a, GLfloat b,
           GLfloat c, point3 ambient, point3 specular, point3 diffuse){
    this->name = name;
    this->position = position;
    this->direction = direction;
    this->angle = angle;
    this->a = a;
    this->b = b;
    this->c = c;
    this->diffuse = diffuse;
    this->specular = specular;
    this->ambient = ambient;
}

void Llum::setTipusLlum(Lights t) {
}


vec3 Llum::getDiffuseIntensity() {
    return(diffuse);
}

vec4 Llum::getLightPosition() {
    return(position);
}


void Llum::setDiffuseIntensity(vec3 i) {
// el float que es reb ha de multiplicar els tres valors de la intensitat digusa de la llum
   this->diffuse = i;
}

void Llum::setLightPosition(vec4 v) {
    position = v;
}

void Llum::switchOnOff() {
    on = !on;

}
void Llum::toGPU(QGLShaderProgram *program){
    //gl_IdLlum  luz;
    gl_IdLlum  luz[3];
    int llumActual = this->id;
  //  qDebug() << "Estic en el togpu";
    luz[llumActual].ambient = program->uniformLocation(QString("glLlums[%1].ambient").arg(llumActual));
    luz[llumActual].position = program->uniformLocation(QString("glLlums[%1].position").arg(llumActual));
    luz[llumActual].direction = program->uniformLocation(QString("glLlums[%1].direction").arg(llumActual));
    luz[llumActual].angle = program->uniformLocation(QString("glLlums[%1].angle").arg(llumActual));
    luz[llumActual].a = program->uniformLocation(QString("glLlums[%1].a").arg(llumActual));
    luz[llumActual].b = program->uniformLocation(QString("glLlums[%1].b").arg(llumActual));
    luz[llumActual].c = program->uniformLocation(QString("glLlums[%1].c").arg(llumActual));
    luz[llumActual].diffuse = program->uniformLocation(QString("glLlums[%1].diffuse").arg(llumActual));
    luz[llumActual].specular = program->uniformLocation(QString("glLlums[%1].specular").arg(llumActual));
    //luz.position = program->uniformLocation("glLlums.position");
    //luz[llumActual].ambient = program->uniformLocation("glLlums[llumActual].ambient");

   /* luz.position = program->uniformLocation(this->name + ".position");
    luz.direction = program->uniformLocation(this->name + ".direction");
    luz.angle = program->uniformLocation(this->name + ".angle");
    luz.a = program->uniformLocation(this->name + ".a");
    luz.b = program->uniformLocation(this->name + ".b");
    luz.c = program->uniformLocation(this->name + ".c");
    luz.ambient = program->uniformLocation(this->name + ".ambient");
    luz.diffuse = program->uniformLocation(this->name + ".diffuse");
    luz.specular = program->uniformLocation(this->name + ".specular");
    */
    glUniform3fv(luz[llumActual].ambient, 1, this->ambient);
    glUniform4fv(luz[llumActual].position, 1, this->position);
    glUniform4fv(luz[llumActual].direction, 1, this->direction);
    glUniform1f(luz[llumActual].angle, this->angle);
    glUniform1f(luz[llumActual].a, this->a);
    glUniform1f(luz[llumActual].b, this->b);
    glUniform1f(luz[llumActual].c, this->c);
    glUniform3fv(luz[llumActual].ambient, 1, this->ambient);
    glUniform3fv(luz[llumActual].diffuse, 1, this->diffuse);
    glUniform3fv(luz[llumActual].specular, 1, this->specular);


   }
